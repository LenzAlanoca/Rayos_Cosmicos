-- =====================================================================
-- SCRIPT MAESTRO: ejecuta todos los scripts en orden
-- USO:
--   1) psql -U postgres -f 01_crear_database.sql      <- crea la BD
--   2) psql -U postgres -d rayos_cosmicos -f 00_install_all.sql
--      (este archivo) ejecuta los demás dentro de la BD ya creada.
-- =====================================================================

\echo '>>> Instalando esquema completo de rayos_cosmicos...'

\i 02_crear_tablas.sql
\i 03_crear_indices.sql
\i 04_datos_iniciales.sql
\i 05_crear_vistas.sql
\i 06_funciones_triggers.sql

\echo ''
\echo '======================================================='
\echo '  INSTALACION COMPLETA'
\echo '  Base de datos rayos_cosmicos lista para usarse.'
\echo '======================================================='
