-- =====================================================================
-- SCRIPT 04: DATOS INICIALES (SEED)
-- psql -U postgres -d rayos_cosmicos -f 04_datos_iniciales.sql
-- =====================================================================
-- Inserta los datos base del sistema:
--   - 2 usuarios (admin + investigador)
--   - 1 tipo de dispositivo (Detector de muones)
--   - 2 estaciones (Chacaltaya y Cota Cota)
--   - 1 dispositivo real (UMSA_EA_0x2F1_2026)
--   - 7 variables medidas (las 7 columnas del log)
-- =====================================================================

-- ----------------------- USUARIOS -----------------------
-- Las contraseñas se almacenan con bcrypt vía pgcrypto.
-- Contraseñas en claro (cambiar en producción):
--   admin@umsa.bo         -> Admin1234
--   investigador@umsa.bo  -> Invest1234
INSERT INTO usuario (nombre, correo, contrasena, rol)
VALUES
    ('Administrador', 'admin@umsa.bo',
     crypt('Admin1234', gen_salt('bf', 10)), 'ADMIN'),
    ('Investigador', 'investigador@umsa.bo',
     crypt('Invest1234', gen_salt('bf', 10)), 'INVESTIGADOR')
ON CONFLICT (correo) DO NOTHING;

-- ----------------------- TIPO DE DISPOSITIVO -----------------------
INSERT INTO tipo_dispositivo (nombre, descripcion)
VALUES
    ('Detector Muones', 'Detector de rayos cósmicos y muones')
ON CONFLICT (nombre) DO NOTHING;

-- ----------------------- ESTACIONES -----------------------
INSERT INTO estacion (nombre, ubicacion, latitud, longitud, altitud)
VALUES
    ('Chacaltaya', 'Laboratorio de Física Cósmica UMSA',
     -16.350000, -68.120000, 5200.00),
    ('Cota Cota',  'Campus UMSA, La Paz',
     -16.539722, -68.069444, 3450.00)
ON CONFLICT (nombre) DO NOTHING;

-- ----------------------- DISPOSITIVO REAL -----------------------
-- Basado en el código: UMSA_EA_0x2F1_2026
INSERT INTO dispositivo (
    id_estacion, id_tipo, codigo_hardware, nombre, modelo,
    extension_log, formato_log, estado_actual, activo
)
SELECT
    e.id_estacion,
    t.id_tipo,
    '0x2F1',
    'Detector Muones Principal',
    'EA',
    '.log',
    'CSV_SIMPLE',
    'ACTIVO',
    TRUE
FROM estacion e, tipo_dispositivo t
WHERE e.nombre = 'Chacaltaya' AND t.nombre = 'Detector Muones'
ON CONFLICT (codigo_hardware, id_estacion) DO NOTHING;

-- ----------------------- VARIABLES (7 columnas del log) -----------------------
-- Ejemplo de línea:
-- 838, 404, 798, 0, 6676, 9735, 6929, Thu Apr 16 14:19:47 2026
INSERT INTO variable_medida (id_tipo, nombre, unidad, posicion_columna, descripcion)
SELECT t.id_tipo, v.nombre, v.unidad, v.posicion_columna, v.descripcion
FROM tipo_dispositivo t,
(VALUES
    ('coincidencia_ch0_ch2', 'cuentas/min', 1, 'Coincidencias entre detectores CH0 y CH2'),
    ('coincidencia_ch1',     'cuentas/min', 2, 'Coincidencias detector CH1'),
    ('coincidencia_total',   'cuentas/min', 3, 'Coincidencias generales'),
    ('flag_estado',          'flag',        4, 'Estado / error del detector'),
    ('raw_ch0',              'cuentas/min', 5, 'Cuentas brutas canal 0'),
    ('raw_ch1',              'cuentas/min', 6, 'Cuentas brutas canal 1'),
    ('raw_ch2',              'cuentas/min', 7, 'Cuentas brutas canal 2')
) AS v(nombre, unidad, posicion_columna, descripcion)
WHERE t.nombre = 'Detector Muones'
ON CONFLICT (id_tipo, posicion_columna) DO NOTHING;

\echo '>>> Datos iniciales insertados correctamente'

-- Verificación
SELECT 'Usuarios'       AS tabla, COUNT(*) AS total FROM usuario
UNION ALL SELECT 'Tipos',         COUNT(*) FROM tipo_dispositivo
UNION ALL SELECT 'Estaciones',    COUNT(*) FROM estacion
UNION ALL SELECT 'Dispositivos',  COUNT(*) FROM dispositivo
UNION ALL SELECT 'Variables',     COUNT(*) FROM variable_medida;
