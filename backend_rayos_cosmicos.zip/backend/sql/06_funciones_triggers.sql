-- =====================================================================
-- SCRIPT 06: FUNCIONES Y TRIGGERS
-- psql -U postgres -d rayos_cosmicos -f 06_funciones_triggers.sql
-- =====================================================================

-- ----------------------------------------------------------------------
-- fn_notificar_evento(): notifica vía LISTEN/NOTIFY de Postgres cada vez
--                        que se inserta un nuevo valor_medido. Permite
--                        que el backend Node.js haga streaming en vivo
--                        sin polling.
-- ----------------------------------------------------------------------
CREATE OR REPLACE FUNCTION fn_notificar_evento()
RETURNS TRIGGER AS $$
DECLARE
    payload JSON;
BEGIN
    SELECT json_build_object(
        'id_evento',   ev.id_evento,
        'fecha_hora',  ev.fecha_hora,
        'id_dispositivo', a.id_dispositivo,
        'numero_linea', ev.numero_linea
    )
    INTO payload
    FROM evento_cientifico ev
    JOIN archivo_log a ON a.id_archivo = ev.id_archivo
    WHERE ev.id_evento = NEW.id_evento;

    PERFORM pg_notify('nuevo_evento', payload::text);
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Disparar la notificación una sola vez por evento (cuando se inserta
-- el primer valor del evento, suficiente para el dashboard).
DROP TRIGGER IF EXISTS tr_notificar_evento ON valor_medido;
CREATE TRIGGER tr_notificar_evento
AFTER INSERT ON valor_medido
FOR EACH ROW
EXECUTE FUNCTION fn_notificar_evento();

-- ----------------------------------------------------------------------
-- fn_log_cambio_estado(): cada vez que cambia el estado_actual de un
--                         dispositivo, lo registra automáticamente.
-- ----------------------------------------------------------------------
CREATE OR REPLACE FUNCTION fn_log_cambio_estado()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.estado_actual IS DISTINCT FROM OLD.estado_actual THEN
        INSERT INTO log_estado_maquina (
            id_dispositivo, estado_anterior, estado_nuevo, comentario
        ) VALUES (
            NEW.id_dispositivo, OLD.estado_actual, NEW.estado_actual,
            'Cambio automático registrado por trigger'
        );
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS tr_log_cambio_estado ON dispositivo;
CREATE TRIGGER tr_log_cambio_estado
AFTER UPDATE ON dispositivo
FOR EACH ROW
EXECUTE FUNCTION fn_log_cambio_estado();

-- ----------------------------------------------------------------------
-- fn_validar_login(correo, password): retorna el usuario si la
--                                     contraseña coincide.
-- ----------------------------------------------------------------------
CREATE OR REPLACE FUNCTION fn_validar_login(p_correo TEXT, p_password TEXT)
RETURNS TABLE (
    id_usuario INTEGER,
    nombre     VARCHAR,
    correo     VARCHAR,
    rol        VARCHAR
) AS $$
BEGIN
    RETURN QUERY
    SELECT u.id_usuario, u.nombre, u.correo, u.rol
    FROM usuario u
    WHERE u.correo = p_correo
      AND u.activo = TRUE
      AND u.contrasena = crypt(p_password, u.contrasena);
END;
$$ LANGUAGE plpgsql;

\echo '>>> Funciones y triggers creados correctamente'
