-- =====================================================================
-- SCRIPT 02: CREACIÓN DE TABLAS
-- Conectado a la base 'rayos_cosmicos':
--   psql -U postgres -d rayos_cosmicos -f 02_crear_tablas.sql
-- =====================================================================

SET TIME ZONE 'America/La_Paz';

-- ---------------------------------------------------------------------
-- 1. tipo_dispositivo
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS tipo_dispositivo (
    id_tipo        SERIAL PRIMARY KEY,
    nombre         VARCHAR(100) NOT NULL UNIQUE,
    descripcion    TEXT,
    fecha_creacion TIMESTAMP DEFAULT NOW()
);

COMMENT ON TABLE  tipo_dispositivo IS 'Catálogo de tipos de dispositivos científicos';

-- ---------------------------------------------------------------------
-- 2. estacion
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS estacion (
    id_estacion    SERIAL PRIMARY KEY,
    nombre         VARCHAR(100) NOT NULL UNIQUE,
    ubicacion      TEXT,
    latitud        NUMERIC(9,6) CHECK (latitud  BETWEEN -90  AND 90),
    longitud       NUMERIC(9,6) CHECK (longitud BETWEEN -180 AND 180),
    altitud        NUMERIC(8,2) CHECK (altitud  >= 0),
    fecha_creacion TIMESTAMP DEFAULT NOW()
);

COMMENT ON TABLE estacion IS 'Estaciones físicas (Chacaltaya, Cota Cota, etc.)';

-- ---------------------------------------------------------------------
-- 3. dispositivo
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS dispositivo (
    id_dispositivo    SERIAL PRIMARY KEY,
    id_estacion       INTEGER NOT NULL,
    id_tipo           INTEGER NOT NULL,
    codigo_hardware   VARCHAR(100) NOT NULL,
    nombre            VARCHAR(100) NOT NULL,
    modelo            VARCHAR(100),
    extension_log     VARCHAR(20)  DEFAULT '.log',
    formato_log       VARCHAR(50)  DEFAULT 'CSV_SIMPLE',
    estado_actual     VARCHAR(50)  DEFAULT 'INACTIVO',
    activo            BOOLEAN      DEFAULT TRUE,
    fecha_instalacion TIMESTAMP    DEFAULT NOW(),
    CONSTRAINT fk_dispositivo_estacion
        FOREIGN KEY (id_estacion) REFERENCES estacion(id_estacion)
        ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT fk_dispositivo_tipo
        FOREIGN KEY (id_tipo) REFERENCES tipo_dispositivo(id_tipo)
        ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT uq_dispositivo_codigo
        UNIQUE (codigo_hardware, id_estacion),
    CONSTRAINT ck_estado_actual
        CHECK (estado_actual IN ('ACTIVO','INACTIVO','MANTENIMIENTO','ERROR','APAGADO'))
);

COMMENT ON TABLE dispositivo IS 'Dispositivos físicos en cada estación';

-- ---------------------------------------------------------------------
-- 4. archivo_log
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS archivo_log (
    id_archivo        BIGSERIAL PRIMARY KEY,
    id_dispositivo    INTEGER NOT NULL,
    nombre_archivo    TEXT NOT NULL,
    ruta_archivo      TEXT,
    fecha_inicio      TIMESTAMP,
    fecha_importacion TIMESTAMP DEFAULT NOW(),
    hash_archivo      TEXT,
    tamano_bytes      BIGINT,
    lineas_totales    INTEGER,
    CONSTRAINT fk_archivo_dispositivo
        FOREIGN KEY (id_dispositivo) REFERENCES dispositivo(id_dispositivo)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT uq_archivo_hash UNIQUE (hash_archivo)
);

-- ---------------------------------------------------------------------
-- 5. evento_cientifico
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS evento_cientifico (
    id_evento    BIGSERIAL PRIMARY KEY,
    id_archivo   BIGINT NOT NULL,
    numero_linea INTEGER NOT NULL,
    fecha_hora   TIMESTAMP NOT NULL,
    CONSTRAINT fk_evento_archivo
        FOREIGN KEY (id_archivo) REFERENCES archivo_log(id_archivo)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT uq_evento_archivo_linea
        UNIQUE (id_archivo, numero_linea)
);

-- ---------------------------------------------------------------------
-- 6. variable_medida
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS variable_medida (
    id_variable      SERIAL PRIMARY KEY,
    id_tipo          INTEGER NOT NULL,
    nombre           VARCHAR(100) NOT NULL,
    unidad           VARCHAR(20),
    posicion_columna INTEGER NOT NULL,
    descripcion      TEXT,
    CONSTRAINT fk_variable_tipo
        FOREIGN KEY (id_tipo) REFERENCES tipo_dispositivo(id_tipo)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT uq_variable_tipo_posicion UNIQUE (id_tipo, posicion_columna),
    CONSTRAINT uq_variable_tipo_nombre   UNIQUE (id_tipo, nombre)
);

-- ---------------------------------------------------------------------
-- 7. valor_medido
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS valor_medido (
    id_valor    BIGSERIAL PRIMARY KEY,
    id_evento   BIGINT NOT NULL,
    id_variable INTEGER NOT NULL,
    valor       NUMERIC(20,6),
    CONSTRAINT fk_valor_evento
        FOREIGN KEY (id_evento) REFERENCES evento_cientifico(id_evento)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fk_valor_variable
        FOREIGN KEY (id_variable) REFERENCES variable_medida(id_variable)
        ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT uq_valor_evento_variable UNIQUE (id_evento, id_variable)
);

-- ---------------------------------------------------------------------
-- 8. usuario
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS usuario (
    id_usuario     SERIAL PRIMARY KEY,
    nombre         VARCHAR(100) NOT NULL,
    correo         VARCHAR(150) NOT NULL UNIQUE,
    contrasena     TEXT NOT NULL,
    rol            VARCHAR(50)  NOT NULL DEFAULT 'INVESTIGADOR',
    activo         BOOLEAN      DEFAULT TRUE,
    fecha_creacion TIMESTAMP    DEFAULT NOW(),
    ultimo_acceso  TIMESTAMP,
    CONSTRAINT ck_rol_valido
        CHECK (rol IN ('ADMIN','INVESTIGADOR','OPERADOR','VISITANTE'))
);

-- ---------------------------------------------------------------------
-- 9. log_sesion
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS log_sesion (
    id_log     BIGSERIAL PRIMARY KEY,
    id_usuario INTEGER NOT NULL,
    fecha_hora TIMESTAMP DEFAULT NOW(),
    ip_origen  VARCHAR(100),
    user_agent TEXT,
    exitoso    BOOLEAN DEFAULT TRUE,
    CONSTRAINT fk_sesion_usuario
        FOREIGN KEY (id_usuario) REFERENCES usuario(id_usuario)
        ON UPDATE CASCADE ON DELETE CASCADE
);

-- ---------------------------------------------------------------------
-- 10. log_estado_maquina
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS log_estado_maquina (
    id_log_maquina  BIGSERIAL PRIMARY KEY,
    id_dispositivo  INTEGER NOT NULL,
    id_usuario      INTEGER,
    estado_anterior VARCHAR(50),
    estado_nuevo    VARCHAR(50) NOT NULL,
    comentario      TEXT,
    fecha_hora      TIMESTAMP DEFAULT NOW(),
    CONSTRAINT fk_logmaq_dispositivo
        FOREIGN KEY (id_dispositivo) REFERENCES dispositivo(id_dispositivo)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fk_logmaq_usuario
        FOREIGN KEY (id_usuario) REFERENCES usuario(id_usuario)
        ON UPDATE CASCADE ON DELETE SET NULL
);

\echo '>>> Tablas creadas correctamente'
