-- =====================================================================
-- SCRIPT 05: VISTAS PARA EL FRONTEND
-- psql -U postgres -d rayos_cosmicos -f 05_crear_vistas.sql
-- =====================================================================
-- Estas vistas simplifican enormemente las consultas que hace el backend.
-- =====================================================================

-- ----------------------------------------------------------------------
-- v_dispositivos_estado: lista todos los dispositivos con su estación,
--                        tipo, y la cantidad de eventos registrados.
--                        Alimenta el dashboard "Estado de Sensores".
-- ----------------------------------------------------------------------
CREATE OR REPLACE VIEW v_dispositivos_estado AS
SELECT
    d.id_dispositivo,
    d.nombre               AS dispositivo,
    d.codigo_hardware,
    d.modelo,
    d.estado_actual,
    d.activo,
    d.fecha_instalacion,
    e.id_estacion,
    e.nombre               AS estacion,
    e.ubicacion,
    e.latitud,
    e.longitud,
    e.altitud,
    t.id_tipo,
    t.nombre               AS tipo_dispositivo,
    (SELECT COUNT(*) FROM archivo_log a WHERE a.id_dispositivo = d.id_dispositivo)
                           AS total_archivos,
    (SELECT MAX(ev.fecha_hora)
     FROM evento_cientifico ev
     JOIN archivo_log a ON a.id_archivo = ev.id_archivo
     WHERE a.id_dispositivo = d.id_dispositivo)
                           AS ultima_lectura
FROM dispositivo d
JOIN estacion e         ON e.id_estacion = d.id_estacion
JOIN tipo_dispositivo t ON t.id_tipo     = d.id_tipo;

-- ----------------------------------------------------------------------
-- v_eventos_pivot: convierte el modelo EAV a una vista tabular útil para
--                  el detector de muones (7 columnas + tiempo).
--                  Acelera mucho gráficos y exportación.
-- ----------------------------------------------------------------------
CREATE OR REPLACE VIEW v_eventos_muones AS
SELECT
    ev.id_evento,
    ev.fecha_hora,
    a.id_dispositivo,
    d.nombre AS dispositivo,
    e.nombre AS estacion,
    MAX(CASE WHEN v.nombre = 'coincidencia_ch0_ch2' THEN vm.valor END) AS coincidencia_ch0_ch2,
    MAX(CASE WHEN v.nombre = 'coincidencia_ch1'     THEN vm.valor END) AS coincidencia_ch1,
    MAX(CASE WHEN v.nombre = 'coincidencia_total'   THEN vm.valor END) AS coincidencia_total,
    MAX(CASE WHEN v.nombre = 'flag_estado'          THEN vm.valor END) AS flag_estado,
    MAX(CASE WHEN v.nombre = 'raw_ch0'              THEN vm.valor END) AS raw_ch0,
    MAX(CASE WHEN v.nombre = 'raw_ch1'              THEN vm.valor END) AS raw_ch1,
    MAX(CASE WHEN v.nombre = 'raw_ch2'              THEN vm.valor END) AS raw_ch2
FROM evento_cientifico ev
JOIN archivo_log     a  ON a.id_archivo = ev.id_archivo
JOIN dispositivo     d  ON d.id_dispositivo = a.id_dispositivo
JOIN estacion        e  ON e.id_estacion = d.id_estacion
LEFT JOIN valor_medido vm ON vm.id_evento = ev.id_evento
LEFT JOIN variable_medida v ON v.id_variable = vm.id_variable
GROUP BY ev.id_evento, ev.fecha_hora, a.id_dispositivo, d.nombre, e.nombre;

-- ----------------------------------------------------------------------
-- v_estadisticas_diarias: agregados por día y dispositivo
-- ----------------------------------------------------------------------
CREATE OR REPLACE VIEW v_estadisticas_diarias AS
SELECT
    DATE(ev.fecha_hora)            AS fecha,
    a.id_dispositivo,
    d.nombre                       AS dispositivo,
    COUNT(*)                       AS total_eventos,
    AVG(vm.valor)                  AS promedio_general,
    MIN(vm.valor)                  AS minimo,
    MAX(vm.valor)                  AS maximo,
    STDDEV(vm.valor)               AS desviacion
FROM evento_cientifico ev
JOIN archivo_log a       ON a.id_archivo = ev.id_archivo
JOIN dispositivo d       ON d.id_dispositivo = a.id_dispositivo
JOIN valor_medido vm     ON vm.id_evento = ev.id_evento
JOIN variable_medida v   ON v.id_variable = vm.id_variable
WHERE v.nombre = 'coincidencia_total'
GROUP BY DATE(ev.fecha_hora), a.id_dispositivo, d.nombre;

\echo '>>> Vistas creadas correctamente'
