-- =====================================================================
-- SCRIPT 03: ÍNDICES PARA OPTIMIZAR CONSULTAS
-- psql -U postgres -d rayos_cosmicos -f 03_crear_indices.sql
-- =====================================================================
-- Estos índices son CRÍTICOS para el rendimiento del streaming en vivo
-- y de las consultas históricas con miles/millones de eventos.
-- =====================================================================

-- Eventos científicos: búsquedas por archivo y por tiempo
CREATE INDEX IF NOT EXISTS idx_evento_fecha_hora
    ON evento_cientifico (fecha_hora DESC);

CREATE INDEX IF NOT EXISTS idx_evento_archivo_fecha
    ON evento_cientifico (id_archivo, fecha_hora DESC);

-- Valores medidos: el join más caliente del sistema
CREATE INDEX IF NOT EXISTS idx_valor_evento
    ON valor_medido (id_evento);

CREATE INDEX IF NOT EXISTS idx_valor_variable
    ON valor_medido (id_variable);

CREATE INDEX IF NOT EXISTS idx_valor_evento_variable
    ON valor_medido (id_evento, id_variable);

-- Archivos: por dispositivo y por fecha
CREATE INDEX IF NOT EXISTS idx_archivo_dispositivo
    ON archivo_log (id_dispositivo);

CREATE INDEX IF NOT EXISTS idx_archivo_fecha_inicio
    ON archivo_log (fecha_inicio DESC);

-- Dispositivos
CREATE INDEX IF NOT EXISTS idx_dispositivo_estacion
    ON dispositivo (id_estacion);

CREATE INDEX IF NOT EXISTS idx_dispositivo_tipo
    ON dispositivo (id_tipo);

CREATE INDEX IF NOT EXISTS idx_dispositivo_activo
    ON dispositivo (activo) WHERE activo = TRUE;

-- Variables
CREATE INDEX IF NOT EXISTS idx_variable_tipo
    ON variable_medida (id_tipo);

-- Logs auxiliares
CREATE INDEX IF NOT EXISTS idx_logsesion_usuario
    ON log_sesion (id_usuario, fecha_hora DESC);

CREATE INDEX IF NOT EXISTS idx_logmaq_dispositivo
    ON log_estado_maquina (id_dispositivo, fecha_hora DESC);

\echo '>>> Indices creados correctamente'
