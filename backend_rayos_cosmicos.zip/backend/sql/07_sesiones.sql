-- =====================================================================
-- SCRIPT 07: TABLA DE SESIONES (login basico)
-- psql -U postgres -d rayos_cosmicos -f 07_sesiones.sql
-- =====================================================================
-- Login basico: cuando un usuario inicia sesion, generamos un token
-- aleatorio que se guarda aqui. El front lo manda en cada request en
-- el header  Authorization: Bearer <token>.
-- Cuando se implemente JWT solo se reemplaza esta tabla y el middleware.
-- =====================================================================

CREATE TABLE IF NOT EXISTS sesion_activa (
    token         TEXT PRIMARY KEY,
    id_usuario    INTEGER NOT NULL,
    fecha_creacion TIMESTAMP DEFAULT NOW(),
    fecha_expiracion TIMESTAMP NOT NULL,
    ip_origen     VARCHAR(100),
    user_agent    TEXT,
    CONSTRAINT fk_sesion_activa_usuario
        FOREIGN KEY (id_usuario) REFERENCES usuario(id_usuario)
        ON UPDATE CASCADE ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_sesion_activa_usuario
    ON sesion_activa (id_usuario);

CREATE INDEX IF NOT EXISTS idx_sesion_activa_expiracion
    ON sesion_activa (fecha_expiracion);

COMMENT ON TABLE sesion_activa IS 'Tokens de sesion para login basico (reemplazable luego por JWT)';

\echo '>>> Tabla de sesiones creada correctamente'
