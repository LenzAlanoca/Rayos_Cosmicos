-- =====================================================================
-- SCRIPT 01: CREACIÓN DE LA BASE DE DATOS
-- Sistema de Recolección de Datos - Grupo Rayos Cósmicos UMSA
-- Detector de Muones Chacaltaya  -->  Administrador UMSA Cota Cota
-- =====================================================================
-- Ejecutar conectado a la base 'postgres' (NO a rayos_cosmicos):
--   psql -U postgres -f 01_crear_database.sql
-- =====================================================================

-- DROP DATABASE IF EXISTS rayos_cosmicos;  -- Descomentar si se quiere reiniciar

CREATE DATABASE rayos_cosmicos
    WITH
    OWNER       = postgres
    ENCODING    = 'UTF8'
    TEMPLATE    = template0
    CONNECTION LIMIT = -1;

COMMENT ON DATABASE rayos_cosmicos
    IS 'Sistema de recolección de datos del grupo de rayos cósmicos UMSA - Detector de muones Chacaltaya';

\c rayos_cosmicos

SET TIME ZONE 'America/La_Paz';

CREATE EXTENSION IF NOT EXISTS pgcrypto;       -- hashing de contraseñas
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";    -- UUIDs

\echo '>>> Base de datos rayos_cosmicos creada correctamente'
